﻿using AzureCosmosApi.Model;
using AzureCosmosApi.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AzureCosmosApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private readonly ICosmosDbService _cosmosDbService;
        public ValuesController(ICosmosDbService cosmosDbService)
        {
            _cosmosDbService = cosmosDbService;
        }

        private static readonly string _endpointUri = "https://7eb57780-0ee0-4-231-b9ee.documents.azure.com:443/";
        private static readonly string _primaryKey = "My8UUsFHmYyVR8175OKuktdGDnp24qQLVLCbHe7u5zKoWJuZjmmvvJm75Fw1j9zSa5Xexm0MrAyceRFSybQAIw==";
        
        [HttpGet]
        public async Task<Record> Get( string id)
        {
            Record rec = new Record();
         
            using (CosmosClient client = new CosmosClient(_endpointUri, _primaryKey))
            {
                var targetDatabase = client.GetDatabase("healthdb");
                var customContainer = targetDatabase.GetContainer("CustomCollection");
                var container = client.GetContainer("healthdb", "document-record");
                var dr = new document_record();
                var icd = new icd_record();
                var pr = new patient_record();
                var dor = new doctor_record();
                var query = container.GetItemQueryIterator<document_record>(new QueryDefinition("SELECT * FROM c where c.id='"+ id + "'"));
                List<document_record> results = new List<document_record>();
                while (query.HasMoreResults)
                {
                    var response = await query.ReadNextAsync();

                    results.AddRange(response.ToList());
                }
                if(results.Count > 0)
                {
                    dr = results[0];

                    var container1 = client.GetContainer("healthdb", "doctor-record");
                    var query1 = container1.GetItemQueryIterator<doctor_record>(new QueryDefinition("SELECT * FROM c where c.id='" + dr.doctor_id + "'"));
                    List<doctor_record> results1 = new List<doctor_record>();
                    while (query1.HasMoreResults)
                    {
                        var response = await query1.ReadNextAsync();

                        results1.AddRange(response.ToList());
                    }
                    if (results1.Count > 0)
                    {
                        dor = results1[0];
                    }

                    var container2 = client.GetContainer("healthdb", "icd-record");
                    var query2 = container2.GetItemQueryIterator<icd_record>(new QueryDefinition("SELECT * FROM c where c.id='" + dr.icdcode + "'"));
                    List<icd_record> results2 = new List<icd_record>();
                    while (query2.HasMoreResults)
                    {
                        var response = await query2.ReadNextAsync();

                        results2.AddRange(response.ToList());
                    }
                    if (results2.Count > 0)
                    {
                        icd = results2[0];
                    }

                    var container3 = client.GetContainer("healthdb", "patient-record");
                    var query3 = container3.GetItemQueryIterator<patient_record>(new QueryDefinition("SELECT * FROM c where c.id='" + dr.patient_id + "'"));
                    List<patient_record> results3 = new List<patient_record>();
                    while (query3.HasMoreResults)
                    {
                        var response = await query3.ReadNextAsync();

                        results3.AddRange(response.ToList());
                    }
                    if (results3.Count > 0)
                    {
                        pr = results3[0];
                    }
                }

                

                rec = new Record
                {
                    document_record = dr,
                    doctor_record = dor,
                    icd_record = icd,
                    patient_record = pr
                };
            }
            return rec;
        }

       
    }
}
